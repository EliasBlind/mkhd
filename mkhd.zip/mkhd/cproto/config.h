/* config.h.  Generated automatically by configure.  */
/* @configure_input@ */
/* $Id: config_h.in,v 4.2 1995/01/01 19:34:59 cthuang Exp $ */

#define SYSTEM_NAME "darwin22.6.0"
#define CPP_DOES_COMMENTS 1
#define YYTEXT_POINTER 1
#define OPT_LINTLIBRARY 1
#define STDC_HEADERS 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRING_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STRINGS_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
#define HAVE_UNISTD_H 1
#define HAVE_GETOPT_H 1
#define HAVE_GETOPT_HEADER 1
#define HAVE_GETOPT 1
#define HAVE_POPEN 1
#define HAVE_STRSTR 1
#define HAVE_TMPFILE 1
#define HAVE_LINK 1
#define HAVE_UNLINK 1
#define HAVE_UNISTD_H 1
#define HAVE_MKSTEMP 1
#define CPP_DOES_ONLY_C_FILES 1
#define BISON_HAS_YYTNAME 1
#define CPP "gcc -E"
