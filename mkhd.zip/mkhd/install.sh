cd cproto
make clean
./configure
make
cd ..
mv "$PWD" "$HOME"/.local/
cd "$HOME"/.local/mkhd
echo 'export PATH="'$PWD':$PATH"' >> ~/.zshrc
source ~/.zshrc
rm "$PWD"/install.sh
